#include "StackType.h"
#include "StackType.cpp"
#include <iostream>

using namespace std;

int main()
{
   string s;
   cout<<"Enter the string :"<<endl;
   cin>>s;
   StackType<char> c;
   for(int i=0;i<s.size();i++){
    c.Push(s[i]);
   }
   cout<<"Reverse string :"<<endl;
   while(!c.IsEmpty())cout<<c.Top(),c.Pop();
   cout<<endl;
}
