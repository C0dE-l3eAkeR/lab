#include "SortedType.h"
#include "SortedType.cpp"
#include <iostream>

using namespace std;

int main()
{
    int n;
    cout<<"Enter number of elements"<<endl;
    cin>>n;
    cout<<"Enter the elements of array A"<<endl;
    SortedType<int>a,b;

    for(int i=0; i<n; i++)
    {
        int x;
        cin>>x;
        a.InsertItem(x);
    }
    cout<<"Enter the elements of array B"<<endl;
    for(int i=0; i<n; i++)
    {
        int x;
        cin>>x;
        b.InsertItem(x);
    }

    int cnt=0;
    for(int i=0; i<n; i++)
    {
        int item1,item2;
        bool found = false;
        a.GetNextItem(item1);
        b.RetrieveItem(item1,found);
        if(found){
            cnt++;
            b.DeleteItem(item1);
        }

    }
    cout<<"Common elements: "<<cnt<<endl;
}
