#include "UnsortedType.h"
#include "UnsortedType.cpp"
#include <iostream>

using namespace std;



int main()
{   int n;
    cout<<"Enter number of elements"<<endl;
    cin>>n;
    cout<<"Enter the elements"<<endl;
    unsorted<int> a(n);
    for(int i=0;i<n;i++){
        int x;
        cin>>x;
        a.InsertItem(x);
    }

    bool found;
    int item;
     cout<<"Enter the item to find"<<endl;
    cin>>item;

    a.RetrieveItem(item,found);

    if(found)
        cout<<"Index: "<< a.RetrieveItem(item,found)<<endl;
    else cout<<-1<<endl;

    return 0;
}
