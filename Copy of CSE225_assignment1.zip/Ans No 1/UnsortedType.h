#ifndef UNSORTEDTYPE_H_INCLUDED
#define UNSORTEDTYPE_H_INCLUDED

#include "string"

template <class ItemType>
class unsorted
{
 public :
 unsorted();
 unsorted(int);
 void MakeEmpty();
 bool IsFull();
 int LengthIs();
 void InsertItem(ItemType);
 void DeleteItem(ItemType);
 int RetrieveItem(ItemType&, bool&);
 void ResetList();
 void GetNextItem(ItemType&);
 void GetPreviousItem(ItemType&);
 private:
 int length;
 int size;
 ItemType *info;
 int currentPos;
};


#endif // UNSORTEDTYPE_H_INCLUDED
