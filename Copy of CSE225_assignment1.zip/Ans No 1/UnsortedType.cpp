#include "UnsortedType.h"
#include "string"
#include "bits/stdc++.h"
template <class ItemType>
unsorted<ItemType>::unsorted()
{
 length = 0;
 size =0;
 info =NULL;
 currentPos = -1;
}
template <class ItemType>
unsorted<ItemType>::unsorted(int n)
{
  info = new  ItemType[n];
 length = 0;
 size =n;
 currentPos = -1;
}
template <class ItemType>
void unsorted<ItemType>::MakeEmpty()
{
length = 0;
}
template <class ItemType>
bool unsorted<ItemType>::IsFull()
{
 //return (length == MAX_ITEMS);
}
template <class ItemType>
int unsorted<ItemType>::LengthIs()
{
 return length;
}
template <class ItemType>
void unsorted<ItemType>::ResetList()
{
 currentPos = -1;
}
template <class ItemType>
void
unsorted<ItemType>::GetNextItem(ItemType&
item)
{
 currentPos++;
 item = info [currentPos] ;
}
template <class ItemType>
void
unsorted<ItemType>::GetPreviousItem(ItemType&
item)
{
 currentPos--;
 if(currentPos<0)
    currentPos=0;
 item = info [currentPos] ;
}

template <class ItemType>
int
unsorted<ItemType>::RetrieveItem(ItemType&
item, bool &found)
{
 int location = 0;
 bool moreToSearch = (location < length);
 found = false;
 while (moreToSearch && !found)
 {
 if(item == info[location])
 {
 found = true;
 //item = info[location];
 return location;
 }
 else
 {
 location++;
 moreToSearch = (location < length);
 }
 }

}
template <class ItemType>
void unsorted<ItemType>::InsertItem(ItemType
item)
{
 info[length] = item;
 length++;
}
template <class ItemType>
void unsorted<ItemType>::DeleteItem(ItemType
item)
{
 int location = 0;
 while (item != info[location])
 location++;
 info[location] = info[length - 1];
 length--;
}



